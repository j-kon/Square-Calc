package com.example.jaykon.squarecalc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    EditText input;
    long result;
    long base;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //toolbar.setLogo(R.mipmap.ic_launcher);

        input = (EditText) findViewById(R.id.input);

    }



    public void calculate(View view) {

        //Get the input and output controls

        TextView output = (TextView) findViewById(R.id.tvOutput);



        //Process the data...

        String s = input.getText().toString();


        if(s.isEmpty()){
            input.setError("Enter an integer");
        }else{
            try{
                base= Integer.parseInt(s);
                result = base * base;
            }catch (Exception e){
                Toast.makeText(this, "Something is wrong "+e, Toast.LENGTH_SHORT).show();
            }

        }



        //Output the result...
        output.setText("Result: " + result);

    }


}
